
package benimjavasorum;

/**
 *
 * @author Ayşenur Erdoğan
 */
public class BenimJavaSorum {

    public static void main(String[] args) {
      hücre hücre1=new hücre ();
      
      hücre1.setHücrecesidi("Bitki Hücresi");
      hücre1.setOrganel("Ribozom");
      hücre1.setOrganelsayisi(8);
      
      hücre1.setOrganel1("Kloroplast", "Lizozom");
       
      System.out.println("Hücrenin çeşidi="+hücre1.getHücrecesidi());
        System.out.println("Hücrenin organeli="+hücre1.getOrganel());
        System.out.println("Hücrenin organel sayısı="+hücre1.getOrganelsayisi());
       
    }
    
}
