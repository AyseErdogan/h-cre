
package benimjavasorum;

/**
 *
 * @author Ayşenur Erdoğan
 */
public class hücre {
    private String organel;
    private String hücrecesidi;
    private int organelsayisi;
     private String organel1;
    public void setOrganel ( String organel){
        this.organel=organel;
    }
    public void setHücrecesidi(String hücrecesidi){
        this.hücrecesidi=hücrecesidi;
    }
    public void setOrganelsayisi(int organelsayisi){
        this.organelsayisi=organelsayisi;
    }
    public void setOrganel1 ( String organel, String organel1){
       this.organel=organel;
       this.organel=organel1;
    }
    public String getOrganel(){
        return this.organel;
    }
     public String getHücrecesidi(){
        return this.hücrecesidi;
    }
     public int getOrganelsayisi(){
         return this.organelsayisi;
    }
     public String getOrganel1 (){
     return this.organel;
      }
    
}
